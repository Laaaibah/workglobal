export const content = {
  support: {
    contact: {
      email: 'hello@workglobal.ai',
      number: '+ 923011181118',
      location: 'G7/2, Islamabad Pakistan'
    },
    organization: {
      faqs: [
        {
          question: 'How does the platform help me find the right candidates?',
          answer: 'Our platform uses smart matching technology to connect you with candidates based on skills, experience, and job fit saving time and improving hiring quality.'
        },
        {
          question: 'How do I post a job on the platform?',
          answer: 'You can create and publish a job in minutes by filling out a simple job form with role details, requirements, and preferences.'
        },
        {
          question: 'Is there a cost to post job listings?',
          answer: 'We offer flexible pricing plans, including free and premium options depending on your hiring needs and visibility requirements.'
        },
        {
          question: 'How candidates are matched to my job postings?',
          answer: 'Our algorithm analyzes candidate profiles and behavior to deliver highly relevant matches aligned with your job criteria.'
        },
        {
          question: 'Can I filter or shortlist candidates?',
          answer: 'Yes, you can easily filter applicants by skills, experience, location, and other criteria, and shortlist the best candidates.'
        },
        {
          question: 'How do I communicate with candidates?',
          answer: 'Employers can directly message candidates through the platform or schedule interviews seamlessly.'
        },
        {
          question: 'Can I manage multiple job postings at once?',
          answer: 'Yes, you can manage all your job listings, applicants, and hiring stages from a centralized dashboard.'
        },
        {
          question: 'How do I track my hiring progress?',
          answer: 'You get access to analytics and dashboards that show application rates, candidate engagement, and hiring progress.'
        }
      ],
    },
    jobseeker: {
      faqs: [
        {
          question: 'How do I create an account?',
          answer: 'You can sign up workglobal using your email or LinkedIn account and complete your profile to start applying for jobs.'
        },
        {
          question: 'Is it free to apply for jobs?',
          answer: 'Yes, applying for jobs on our platform is completely free for all candidates. Whereas to get access to international jobs you will have to subscribe to the premium.'
        },
        {
          question: 'How does job matching work?',
          answer: 'We match you with relevant jobs based on your skills, experience, and preferences to improve your chances of getting hired.'
        },
        {
          question: 'How do I apply for a job?',
          answer: 'You can apply instantly with just a few clicks once your profile is complete.'
        },
        {
          question: 'How can I track my applications?',
          answer: 'Your dashboard allows you to track application status, responses, and interview updates in real time.'
        },
        {
          question: 'How can I improve my chances of getting hired?',
          answer: 'Complete your profile, highlight your skills, and stay active to increase visibility to employers.'
        },
        {
          question: 'Are my personal details safe?',
          answer: 'We ensure your data is protected and only shared with employers when necessary.'
        },
        {
          question: 'What should I do if I face any issues?',
          answer: 'You can contact our support team anytime for assistance with your account or application.'
        }
      ]
    }
  }
};

export default content;
